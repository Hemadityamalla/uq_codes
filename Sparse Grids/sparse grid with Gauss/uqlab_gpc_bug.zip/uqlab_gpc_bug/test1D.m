function y = test1D(X)

y = exp(X+1);